// types/index.ts
export interface UserModel {
  firstName: string;
  lastName: string;
  userName: string;
  phoneNumber: string;

}


